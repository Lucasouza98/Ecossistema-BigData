docker kill echo $(docker ps -a -q)
