docker rmi echo $(docker images -a -q)
